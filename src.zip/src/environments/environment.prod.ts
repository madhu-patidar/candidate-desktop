export const environment = {
  production: true,
  baseUrl: 'https://appstore.wipro.com'
};
